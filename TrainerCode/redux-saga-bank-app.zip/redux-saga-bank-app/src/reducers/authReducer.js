// auth reducer
