# ReactJS State Management

Simple understanding about state management using Redux and Redux Saga from Medium.

# The documentation of this code

[Redux isn't complicated as you think](https://medium.com/dev-genius/reactjs-simple-understanding-redux-with-redux-saga-f635e273e24a)
