JSX : java script and XML  - ES6
html + css + js = components (views + services)

Javascript : ECMA spec 1.0  (var x=10)   js engine
ES5 : object based prog. js (Function  - object)
ES 6 : Object oriented prog. lang (18 new features) 2015
    class Emp extends Bank{
        super()
    }
ES7:ES2017

Typescript: POOP - angular / react/ vue / node JSX

ES5 : babel module   babel.js,
