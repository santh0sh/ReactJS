
import createSetVisibilityFilter from './setVisibilityFilter'
import { visibilityFilterVar } from '../../../cache'

export const setVisibilityFilter = createSetVisibilityFilter(visibilityFilterVar)
