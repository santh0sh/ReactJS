import { GetAllTodos_todos_edges_node } from "../operations/__generated__/GetAllTodos";

export type Todo = GetAllTodos_todos_edges_node;

export type Todos = Todo[];