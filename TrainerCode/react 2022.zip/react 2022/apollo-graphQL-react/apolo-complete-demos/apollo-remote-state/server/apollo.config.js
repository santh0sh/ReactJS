module.exports = {
  service: {
    name: "ac3-todos-backend"
  }
}