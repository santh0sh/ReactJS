
import { InMemoryTodoRepo } from "./implementations/InMemoryTodoRepo";

const todosRepo = new InMemoryTodoRepo();

export { todosRepo };