
import { GetAllTodos_todos } from "../operations/queries/__generated__/GetAllTodos";

export type Todo = GetAllTodos_todos;

export type Todos = Todo[];