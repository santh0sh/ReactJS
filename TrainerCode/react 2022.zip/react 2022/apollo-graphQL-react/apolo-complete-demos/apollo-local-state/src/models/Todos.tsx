
export interface Todo {
  text: string;
  completed: boolean;
  id: number
}

export type Todos = Todo[];