import React from 'react'
import './App.css'
import DemoComponent from './DemoComponent'

function App() {
  return (
    <div className="App">
      <DemoComponent />
    </div>
  )
}

export default App
