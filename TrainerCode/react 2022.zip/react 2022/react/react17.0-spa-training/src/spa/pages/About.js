import React from 'react';
import HomeButton from '../components/HomeButton';

const About = () => {
    return (
        <div>
            <h2>About Page</h2>
            <HomeButton />
        </div>
    );
}

export default About;
