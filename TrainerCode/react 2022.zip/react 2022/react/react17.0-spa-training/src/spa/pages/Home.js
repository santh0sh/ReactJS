import React from 'react';
import Navigation from '../components/Navigation';

const Home = () => {
    return (
        <div>
            <p>Home Page</p>
            <Navigation />  
        </div>
    );
}

export default Home;
    