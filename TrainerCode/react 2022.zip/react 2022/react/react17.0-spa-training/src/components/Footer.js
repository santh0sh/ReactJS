import React from 'react'
//presentation
export const Footer = ()=>{
    return (
        <div  className="bg-dark text-info text-center">
            <h3>Copyright reserved to Dr. DSR Murthy</h3>
        </div>
    )
}