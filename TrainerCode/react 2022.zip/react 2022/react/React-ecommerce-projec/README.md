A fully functional E-Commerce site created using React-Redux.

used Ramda library which is like lodash library. 
Key features:

from Satheesh to everyone:    11:47 AM
Remove .(dot) from Link  ( containers/phones.js ) 
from Satheesh to everyone:    11:47 AM
Line # 32

1. Pagination
2. Searching
3. Categorisation
4. Real world API using superagent and Mocky.io
5. Best practices of developing react application implemented.
6. Add To Basket feature implemented.
7. CRUD operations on the cart


