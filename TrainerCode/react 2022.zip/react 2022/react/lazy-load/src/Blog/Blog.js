import React, { Component } from 'react'
import './Blog.css'
class Blog extends Component {  
    render () {
        return (
            <div className="container">
              <h1>Murthy's Blog Page</h1>
               <h3>mail me at dsrmurthy786@yahoo.com</h3>      
               <h3>Online and Offline trainer for top MNC's</h3>              
            </div>
        )
    }
}
export default Blog