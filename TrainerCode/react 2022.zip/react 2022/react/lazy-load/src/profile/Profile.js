import React, { Component } from 'react'
import './profile.css'
class Profile extends Component {  
    render () {
        return (
            <div className="container">
              <h1>Murthy's profile</h1>
               <h3>Corporate trainer</h3>               
               <h3>M.Tech (IT)</h3>
               <h3>30 years experience in IT</h3>
            </div>
        )
    }
}
export default Profile