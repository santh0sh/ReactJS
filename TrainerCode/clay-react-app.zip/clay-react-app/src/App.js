import './App.css';
import Clay from './Clay';

function App() {
  return (
    <div className="App">      
      <Clay/>
    </div>
  );
}

export default App;
