##  A Simple example using React Portals to create a music player component

### Accompanying blog post at https://medium.com/@ishmaelsibisi/reactjs-portals-a-simple-but-useful-example-41accfb77b7c

## To run

```bash
$ git clone https://github.com/cyber-claws/having-fun-with-portals.git
$ cd having-fun-with-portals/ && npm i
$ npm start
```
