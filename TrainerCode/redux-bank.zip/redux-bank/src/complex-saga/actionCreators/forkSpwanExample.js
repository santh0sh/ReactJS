import * as actionTypes from '../actionTypes/forkSpawnExample'

export function runForkExample() {
  return {type: actionTypes.RUN_FORK}
}

export function runSpawnExample() {
  return {type: actionTypes.RUN_SPAWN}
}

