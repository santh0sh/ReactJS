export const GET_USERS_E = 'sagahelpers/GET_USERS_E';
export const GET_USERS_L = 'sagahelpers/GET_USERS_L';
export const GET_USERS_T = 'sagahelpers/GET_USERS_T';
export const GET_USERS_SUCCESS = 'sagahelpers/GET_USERS_SUCCESS';
export const ERROR = 'sagahelpers/GET_USERS_ERROR';

