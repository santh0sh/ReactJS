export const GET_USERS = 'nonblockingcalls/GET_USERS';
export const GET_USERS_SUCCESS = 'nonblockingcalls/GET_USERS_SUCCESS';

export const GET_CITIES = 'nonblockingcalls/GET_CITIES';
export const GET_CITIES_SUCCESS = 'nonblockingcalls/GET_CITIES_SUCCESS';

export const ERROR = 'nonblockingcalls/ERROR';
