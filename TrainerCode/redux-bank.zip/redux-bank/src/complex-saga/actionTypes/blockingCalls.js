export const GET_USERS = 'blockingcalls/GET_USERS';
export const GET_USERS_SUCCESS = 'blockingcalls/GET_USERS_SUCCESS';

export const GET_CITIES = 'blockingcalls/GET_CITIES';
export const GET_CITIES_SUCCESS = 'blockingcalls/GET_CITIES_SUCCESS';

export const ERROR = 'blockingcalls/ERROR';
