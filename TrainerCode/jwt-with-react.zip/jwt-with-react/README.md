# react-jwt-authentication-example

React (without Redux) - JWT Authentication

Install all required npm packages by running npm install from the command line in the project root folder (where the package.json is located).
Start the application by running npm start from the command line in the project root folder.
Your browser should automatically open at http://localhost:8080 with the login page of the demo React JWT authentication app displayed.

